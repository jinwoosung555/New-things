AertherX Hub
============

Expanded black-themed Luau GUI rebuilt from the supplied Luraph constants metadata.

Added feature categories:
- Farming+: level farming, quests, bosses, mastery, chests, materials, raids, dungeons, enemy magnet controls.
- Combat: aim, fast attack, M1, skills, Haki/Observation, defense, PvP, mastery and weapon controls.
- Fruits: ESP, collection, eating/storage/drop, stock, fruit events and Mirage helpers.
- Sea Events: Prehistoric, Frozen Dimension, Kitsune, Leviathan, Sea Beast, Terror Shark and status helpers.
- Travel: world/island/NPC and named-location navigation controls.
- Race V4: V2/V3/V4 upgrades, trials, moon and status controls.
- Fishing: fishing quest, bait, rods and automation controls.
- Items: fighting styles, swords, Soul Guitar, Cursed Dual Katana, Tushita/Yama and related purchase controls.
- Misc: Anti-AFK, water/boat, graphics, server and mobile UI controls.

The supplied file is a Luraph constants/data table, not a clean source implementation. The added controls therefore expose the feature set without fabricating undocumented remote implementations. Existing local farming/attack helpers remain in the source.
\n\nWorld place IDs added:\n- First Sea: 2753915549\n- Second Sea: 4442272183\n- Third Sea: 7449423635\n\nIsland and NPC destinations are not separate Roblox places; they require in-game CFrame/remote adapters.\n